// incluem a função intersecção
#include "INTERSEC.cpp" 
void UNIAO(vector<int> C,vector<int> &Cl, int p)
// insere o vértice p em no conjunto da clique atual C
{C.push_back(p);
// laço para esvaziar a clique auxiliar	
//	for (unsigned int i=0; i<Cl.size();){Cl.pop_back();}
Cl.clear();
// laço para colocar todos elementos da clique atual na Clique auxiliar	
	for (unsigned int i=0; i<C.size();i++){Cl.push_back(C[i]);}
}
