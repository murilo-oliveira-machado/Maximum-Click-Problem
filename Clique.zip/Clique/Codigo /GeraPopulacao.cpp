#include <random>
#include <chrono>
#include <vector>
#include <iostream>
#include "BuscaHeuristica.cpp"
using namespace std;
void GeraPopulacao(int ** grafo,vector<int>VG,vector<int>GR,int tp,vector<vector<int>>&POP)
{	
vector<int>C;
vector<vector<int>>LT(tp);	
	for( int i = 0; i < tp; i++)	
	{	
		C.clear();//LT.clear();		
		BuscaHeuristica(C,grafo,LT,VG,GR,i);
		for(unsigned int j = 0; j < C.size(); j++)	
		{	
			POP[i].push_back(C[j]);
		}
	}		
}
