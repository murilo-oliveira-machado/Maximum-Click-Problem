#include <random>
#include <chrono>
#include <vector>
#include <iostream>

using namespace std;
void VerificaClique(vector<int>C,int ** grafo,int &erro)
{
unsigned	int aux=0;
	for(unsigned int i = 0; i < C.size(); i++)	
	{  unsigned int cot=0;
		for(unsigned int j = 0; j < C.size(); j++)	
		{
			if (grafo[C[i]][C[j]]==1){cot=cot+1;}
			
		}
		
		if(cot==C.size()-1){aux=aux+1;}		
	
      cout<<C[i]<<" ";	
	}
		
	
	
	
	if (aux!=C.size()){erro=1;}
	
	
}
