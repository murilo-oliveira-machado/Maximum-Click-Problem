# include "UNIAO.cpp"
void CLIQUE(int &contador,vector<int> &C,vector<int> &P,int ** grafo, int ver)
{   

// define variáveis auxiliares	
unsigned int i,j,k;
// define connjunto de vetores 
vector < int> Cl,Pl,LV,P1,Lv;	
// condição que verifica se a clique atual 
//é maior que a clique máxima já encontrada 
//que foi definida inicialmente dentro função UNIÃO 
if (C.size()>CE.size())
{//unsigned int tCE=CE.size();	
// laço para esvaziar a clique máxima  
 //for (i=0; i<tCE; i++)  {CE.pop_back();}
CE.clear();
// laço para atualizar a clique máxima 		   
 for (j=0; j<C.size(); j++){CE.push_back(C[j]);}	
}
// condição que verifica se a árvore pode ser podada
if ((C.size()+P.size())>CE.size())
{
// laço para analisar todos candidatos contido no conjunto P
for (k=0; k<P.size(); )
 {
// atribui a variável p o primeiro vértice do conjuto P	 
int p=P[0];
// remove o vértice p do conjuto P	 
P.erase(P.begin());
// realiza a união entre o conjunto da clique atual e o vértice p
UNIAO(C,Cl,p);
// laço para esvaziar um vetor auxiliar 
  for (i=0; i<Lv.size(); )
   {Lv.pop_back();}
// Realiza a operação de intersecção entre conjunto de candidatos P e os vizinhos do vértice p   
INTERSEC(p,P,Lv,grafo,ver);
// contabiliza o numero de chamadas recursivas 
contador=contador+1;  
// realiza a chamada recursiva
CLIQUE(contador,Cl,Lv,grafo,ver);
  }
 }	
}
