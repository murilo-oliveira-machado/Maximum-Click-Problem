// inclue bibliotecas 
#include <iostream>
#include <cstdlib>
#include <list>
#include <vector>
#include <iterator>
# include <cstdio>
using namespace std;
// define Clique Maxima como variável Global
vector < int> CE;
void INTERSEC(int &p, vector<int> &P,vector<int> &LV, int ** grafo,int ver)
{

	
// laço para realizar a intersecção entre os vizinhos do vértice p e os vértices candidados do conjunto P
for ( int i=1; i<=ver; i++)
  {
	  if (grafo[p][i]==1){
	  for (unsigned int j=0; j<P.size(); j++)
     {// condição que verifica se o vizinho j de p está contido em P 
		 if (i==P[j])
		 {LV.push_back(i);j=P.size()+1;}}				  
      }
   }	
	}







