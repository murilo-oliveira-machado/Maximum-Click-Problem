#include <random>
#include <chrono>
#include <vector>
#include <iostream>
#include "GeraVizinhaca.cpp"
using namespace std;
void BuscaHeuristica(vector<int> &C,int ** grafo,vector<vector<int>>LT,vector<int>VG,vector<int>GR,int IP)
{
	unsigned seed = chrono::system_clock::now().time_since_epoch().count();
	default_random_engine generator (seed);	
	int aux;	
	vector<int> V,G;
	
	    GeraVizinhaca(C,grafo,LT,VG,V,IP);
		while(V.size()!=0)	
		{			
			G.clear();
			for(unsigned int i = 0; i < V.size(); i++)	
			{
				G.push_back(GR[V[i]]);
			}	
		    discrete_distribution<int> second (G.begin(),G.end());
			aux = second(generator);
			C.push_back(V[aux]);	
			V.clear();
			GeraVizinhaca(C,grafo,LT,VG,V,IP);
					
		}
		
		
	
}
