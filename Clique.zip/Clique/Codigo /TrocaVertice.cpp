#include <vector>
#include <iostream>
#include <random>
#include <chrono>
#include "GeraVizinhacaTroca.cpp"
using namespace std;
void TrocaVertice(int **grafo,vector<int> &C, vector<vector<int>> &LT,vector<int> VG,int ver,vector<int>GR,int IP)
{
	unsigned seed = chrono::system_clock::now().time_since_epoch().count();
	default_random_engine generator (seed);	
	int aux,aux2;
    vector<int>V,MGV;
	GeraVizinhacaTroca(C,grafo,LT,VG,V,IP);
	for (unsigned int i=0; i<V.size(); i++)
	{
		MGV.push_back(GR[V[i]]);
	}
	
	if (V.size()!=0)
	{
		discrete_distribution<int> second (MGV.begin(),MGV.end());
		aux = second(generator);
		
	    for (unsigned int j=0; j<C.size(); j++)
		{	
			if (grafo[C[j]][V[aux]]==0){aux2=j;}
		}
//		LT[IP].push_back(C[aux2]);
		C.erase(C.begin()+aux2);C.push_back(V[aux]);		
	}
	
}
