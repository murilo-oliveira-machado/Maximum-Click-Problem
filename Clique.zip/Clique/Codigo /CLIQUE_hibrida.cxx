#include <iostream>
#include <cstdlib>
#include <list>
#include <vector>
#include <string>
#include <iterator>
# include <cstdio>
using namespace std;
#include <fstream>
#include <iostream>
#include <ctime>
#include <climits>
# include <cmath>
#include "CLIQUE.cpp"
#include "VerificaClique.cpp"
#include "GeraPopulacao.cpp"
#include "TrocaVertice.cpp"
#include "RemoveVertice.cpp"
#include "AtualizaLT.cpp"
int main(int argc, char **argv)
{
srand (time(NULL));

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock200_1.txt");
//int are= 14834 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock200_2.txt");
//int are= 9876 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock200_3.txt");
//int are= 12048; int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock200_4.txt");
//int are= 13089 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock400_1.txt");
//int are= 59723 ;int ver=400;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock400_2.txt");
//int are= 59786 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock400_3.txt");
//int are= 59681 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock400_4.txt");
//int are= 59765 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock800_1.txt");
//int are= 207505 ;int ver=800;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock800_2.txt");
//int are= 208166 ;int ver=800;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock800_3.txt");
//int are= 207333 ;int ver=800;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock800_4.txt");
//int are= 207643 ;int ver=800;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/c125_9.txt");
//int are= 6963 ;int ver=125;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/c250_9.txt");
//int are= 27984 ;int ver=250;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/c500_9.txt");
//int are= 112332 ;int ver=500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/c1000_9.txt");
//int are= 450079 ;int ver=1000;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/c2000_5.txt");
//int are= 999836 ;int ver=2000;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/c2000_9.txt");
//int are= 1799532 ;int ver=2000;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/c4000_5.txt");
//int are= 4000268 ;int ver=4000;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/cfat200_1.txt");
//int are= 1534 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/cfat200_2.txt");
//int are= 3235 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/cfat200_5.txt");
//int are= 8473;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/cfat500_1.txt");
//int are= 4459 ;int ver=500;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/cfat500_2.txt");
//int are= 9139 ;int ver=500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/cfat500_5.txt");
//int are= 23191 ;int ver=500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/cfat500_10.txt");
//int are= 46627 ;int ver=500;



//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/DSJC500_5.txt");
//int are= 125248 ;int ver=500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/DSJC1000_5.txt");
//int are= 499652 ;int ver=1000;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/gen200_p0.9_44.txt");
//int are= 17910 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/gen200_p0.9_55.txt");
//int are= 17910 ;int ver=200;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/gen400_p0.9_55.txt");
//int are= 71820 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/gen400_p0.9_65.txt");
//int are= 71820 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/gen400_p0.9_75.txt");
//int are= 71820 ;int ver=400;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/hamming6_2.txt");
//int are= 1824 ;int ver=64;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/hamming6_4.txt");
//int are= 704 ;int ver=64;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/hamming8_2.txt");
//int are= 31616 ;int ver=256;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/hamming8_4.txt");
//int are= 20864 ;int ver=256;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/hamming10_2.txt");
//int are=  518656 ;int ver=1024;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/hamming10_4.txt");
//int are= 434176 ;int ver=1024;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/johnson8_24.txt");
//int are= 210 ;int ver=28;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/johnson8_44.txt");
//int are= 1855 ;int ver=70;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/johnson16_24.txt");
//int are= 5460 ;int ver=120;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/johnson32_24.txt");
//int are= 107880 ;int ver=496;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/keller4.txt");
//int are= 9435 ;int ver=171;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/keller5.txt");
//int are= 225990 ;int ver=776;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/keller6.txt");
//int are= 4619898 ;int ver=3361;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/mann_a9.txt");
//int are= 918 ;int ver=45;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/mann_a27.txt");
//int are= 70551 ;int ver=378;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/mann_a45.txt");
//int are= 533115 ;int ver=1035;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/mann_a81.txt");
//int are= 5506380 ;int ver=3321;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat300_1.txt");
//int are= 10933;int ver=300;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat300_2.txt");
//int are= 21928;int ver=300;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat300_3.txt");
//int are= 33390;int ver=300;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat500_1.txt");
//int are= 31569;int ver=500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat500_2.txt");
//int are= 62946;int ver=500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat500_3.txt");
//int are= 93800;int ver=500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat700_1.txt");
//int are= 60999;int ver=700;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat700_2.txt");
//int are= 121728;int ver=700;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat700_3.txt");
//int are= 183010;int ver=700;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat1000_1.txt");
//int are= 122253;int ver=1000;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat1000_2.txt");
//int are= 244799;int ver=1000;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat1000_3.txt");
//int are= 371746;int ver=1000;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat1500_1.txt");
//int are= 284923;int ver=1500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat1500_2.txt");
//int are= 568960;int ver=1500;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/phat1500_3.txt");
//int are= 847244;int ver=1500;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san200_0.7_1.txt");
//int are= 13930 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san200_0.7_2.txt");
//int are= 13930 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san200_0.9_1.txt");
//int are= 17910 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san200_0.9_2.txt");
//int are= 17910 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san200_0.9_3.txt");
//int are= 17910 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san400_0.5_1.txt");
//int are= 39900 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san400_0.7_1.txt");
//int are= 55860 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san400_0.7_2.txt");
//int are= 55860 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san400_0.7_3.txt");
//int are= 55860 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san400_0.9_1.txt");
//int are= 71820 ;int ver=400;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san1000.txt");
//int are= 250500 ;int ver=1000;



//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/sanr200_0.7.txt");
//int are= 13868 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/sanr200_0.9.txt");
//int are= 17863 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/sanr400_0.5.txt");
//int are= 39984 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/sanr400_0.7.txt");
//int are= 55869 ;int ver=400;


//////////////////////////////////////////


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock200_1.txt");
//int are= 14834 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock200_2.txt");
//int are= 9876 ;int ver=200;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock400_2.txt");
//int are= 59786 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/brock400_4.txt");
//int are= 59765 ;int ver=400;

//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san200_0.7_1.txt");
//int are= 13930 ;int ver=200;

ifstream arquivo("/home/badaro/Área de Trabalho/CliqueT/frb30-15-1.clq");
int are= 83198 ;int ver=450;


//ifstream arquivo("/home/badaro/Área de Trabalho/AmosClique/san200_0.9_1.txt");
//int are= 17910 ;int ver=200;


int tp=10;
vector<int> GR(ver+1),VG,C,V,IND,IND2,IauxPOP;

vector<vector<int>> POP(tp),LT(tp),I(tp),auxPOP(tp);

string x;int y,z;

int **grafo = new int *[ver+1];
for(int i = 0; i < (ver+1); i++)
      grafo[i] = new int[ver+1];
for(int i = 0; i < (tp); i++)      
{
      
	for(int j = 0; j < (ver+1); j++)      
	{
		I[i].push_back(0); 			
	}           
}    
 
unsigned int Cmax=0;
      
for (int i=1; i<=are; i++){arquivo >> x;arquivo >> y;arquivo >> z; grafo[y][z]=1;grafo[z][y]=1;GR[y]=GR[y]+1;GR[z]=GR[z]+1;}

for (int i=1; i<=ver; i++){VG.push_back(i);}


unsigned int lt=1;
double T0=5;
double Temp=T0;
int QI=10;
double CMAX=0;double tl=50;
for (int l=0; l<tl; l++)
{   	
	Cmax=0;Temp=T0;QI=10; IauxPOP.clear();GeraPopulacao(grafo,VG,GR,tp,POP);
	while (Temp>0)
	{		
				
		for (int i=0; i<QI; i++)
		{   
			for (int j=0; j<tp; j++)
			{  
				IND.clear();IND2.clear();int contador=0;
				for (unsigned int k=0; k<POP[j].size(); k++){IND.push_back(POP[j][k]);IND2.push_back(POP[j][k]);}
					
				
//				TrocaVertice(grafo,IND,LT,VG,ver,GR,j);
				RemoveVertice(IND,GR,ver,LT,j);
				unsigned int ti=IND.size();
				V.clear();GeraVizinhaca(IND,grafo,LT,VG,V,j);
				CE.clear();CLIQUE(contador,IND,V,grafo,ver);
				unsigned int tf=CE.size();
				
				
				
				//cout<<tf-ti<<endl;
				//cin.get();
				if (tf-ti>1)
				{
					POP[j].clear();for (unsigned int k=0; k<CE.size(); k++){POP[j].push_back(CE[k]);}
					
				}
				else
				{
					

					for (unsigned int k=0; k<CE.size(); k++)
					{   int SinAum=0;
						for (unsigned int kk=k; kk<IND2.size(); kk++)
						{
							if (CE[k]==IND2[kk]){SinAum=1;}
						}
						if (SinAum==0)
						{
							if (LT[j].size()<lt){LT[j].push_back(CE[k]);}
							else{LT[j].erase(LT[j].begin());}
							
						}
						
					}
					
					double R = ((double) rand() / (RAND_MAX));


					if (R<Temp/T0)
					{
						TrocaVertice(grafo,IND2,LT,VG,ver,GR,j);
						RemoveVertice(IND2,GR,ver,LT,j);	
						BuscaHeuristica(IND2,grafo,LT,VG,GR,j);
						POP[j].clear();for (unsigned int k=0; k<IND2.size(); k++){POP[j].push_back(IND2[k]);}
					}
					else
					{
						TrocaVertice(grafo,IND2,LT,VG,ver,GR,j);
						RemoveVertice(IND2,GR,ver,LT,j);
						V.clear();			
						GeraVizinhaca(IND2,grafo,LT,VG,V,j);
						CE.clear();
						CLIQUE(contador,IND2,V,grafo,ver);
						POP[j].clear();for (unsigned int k=0; k<IND2.size(); k++){POP[j].push_back(IND2[k]);}					
					}	
				}
			}

			for(int k = 0; k< (tp); k++) 
			{
				if (POP[k].size()>Cmax)
				{
					IauxPOP.clear();
					for(unsigned int w = 0; w< POP[k].size(); w++) {IauxPOP.push_back(POP[k][w]);}
					Cmax=POP[k].size();
					
				}
				
			}		
		}

	
	for(int i = 0; i < (tp); i++)      
	{ POP[i].clear();LT[i].clear();}    

	GeraPopulacao(grafo,VG,GR,tp,POP);

	POP[0].clear(); 
	for(unsigned int i = 0; i < IauxPOP.size(); i++)      
	{    
	  POP[0].push_back(IauxPOP[i]);		
	}
		
	
	
	QI=QI+1;	
	Temp=Temp-1;
	}
int erro=0;
VerificaClique(IauxPOP,grafo,erro);
cout<<erro<<endl;

for(int i = 0; i < (tp); i++){ POP[i].clear();LT[i].clear();}    

cout<<Cmax<<endl;
CMAX=CMAX+Cmax;
}
cout<<"Media"<<endl;
cout<<CMAX/tl<<endl;

return 0;
}

