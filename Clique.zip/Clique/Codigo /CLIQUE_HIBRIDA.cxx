#include <iostream>
#include <cstdlib>
#include <list>
#include <vector>
#include <cstring>
#include <iterator>
# include <cstdio>
using namespace std;
#include <fstream>
#include <iostream>
#include <ctime>
# include <cmath>
#include <climits>
#include "CLIQUE.cpp"
#include "VerificaClique.cpp"
#include "GeraPopulacao.cpp"
#include "TrocaVertice.cpp"
#include "RemoveVertice.cpp"
#include "AtualizaLT.cpp"
int main(int argc, char **argv)
{
clock_t  tempi,tempf;

tempi = clock();	
	
char* caminho;
int are;
int ver;

for(int i=1; i < argc;) {
	if(strcmp(argv[i], "-i") == 0) {
		caminho = argv[i+1];
		i=i+2;
	}
}

ifstream arquivo(caminho);

arquivo >> are;
arquivo >> ver;
	
	
	
	
	
	
	
	
srand (time(NULL));
//tamanho da população 
int tp=25;
vector<int> GR(ver+1),VG,C,V,IND,IND2,IauxPOP;

vector<vector<int>> POP(tp),LT(tp),I(tp),auxPOP(tp);

string x;int y,z;

int **grafo = new int *[ver+1];
for(int i = 0; i < (ver+1); i++)
      grafo[i] = new int[ver+1];
for(int i = 0; i < (tp); i++)      
{
      
	for(int j = 0; j < (ver+1); j++)      
	{
		I[i].push_back(0); 			
	}           
}    
 

      
for (int i=1; i<=are; i++){arquivo >> x;arquivo >> y;arquivo >> z; grafo[y][z]=1;grafo[z][y]=1;GR[y]=GR[y]+1;GR[z]=GR[z]+1;}

for (int i=1; i<=ver; i++){VG.push_back(i);}

//Tamanho da Lista Tabu
unsigned int lt=4;
//Temperatura Inicial
double T0=5;
double Temp=T0;
//Quantidade de Iteração
int QI=10;
//incremento temperatura
int pQI=6;
unsigned int Cmax=0;
  	
	IauxPOP.clear();GeraPopulacao(grafo,VG,GR,tp,POP);
	while (Temp>0)
	{		
				
		for (int i=0; i<QI; i++)
		{   
			for (int j=0; j<tp; j++)
			{  
				IND.clear();IND2.clear();int contador=0;
				for (unsigned int k=0; k<POP[j].size(); k++){IND.push_back(POP[j][k]);IND2.push_back(POP[j][k]);}
					
				
//				TrocaVertice(grafo,IND,LT,VG,ver,GR,j);
				RemoveVertice(IND,GR,ver,LT,j);
				unsigned int ti=IND.size();
				V.clear();GeraVizinhaca(IND,grafo,LT,VG,V,j);
				CE.clear();CLIQUE(contador,IND,V,grafo,ver);
				unsigned int tf=CE.size();
				
				
				
				//cout<<tf-ti<<endl;
				//cin.get();
				if (tf-ti>1)
				{
					POP[j].clear();for (unsigned int k=0; k<CE.size(); k++){POP[j].push_back(CE[k]);}
					
				}
				else
				{
					

					for (unsigned int k=0; k<CE.size(); k++)
					{   int SinAum=0;
						for (unsigned int kk=k; kk<IND2.size(); kk++)
						{
							if (CE[k]==IND2[kk]){SinAum=1;}
						}
						if (SinAum==0)
						{
							if (LT[j].size()<lt){LT[j].push_back(CE[k]);}
							else{LT[j].erase(LT[j].begin());}
							
						}
						
					}
					
					double R = ((double) rand() / (RAND_MAX));


					if (R<Temp/T0)
					{
						TrocaVertice(grafo,IND2,LT,VG,ver,GR,j);
						RemoveVertice(IND2,GR,ver,LT,j);	
						BuscaHeuristica(IND2,grafo,LT,VG,GR,j);
						POP[j].clear();for (unsigned int k=0; k<IND2.size(); k++){POP[j].push_back(IND2[k]);}
					}
					else
					{
						TrocaVertice(grafo,IND2,LT,VG,ver,GR,j);
						RemoveVertice(IND2,GR,ver,LT,j);
						V.clear();			
						GeraVizinhaca(IND2,grafo,LT,VG,V,j);
						CE.clear();
						CLIQUE(contador,IND2,V,grafo,ver);
						POP[j].clear();for (unsigned int k=0; k<IND2.size(); k++){POP[j].push_back(IND2[k]);}					
					}	
				}
			}

			for(int k = 0; k< (tp); k++) 
			{
				if (POP[k].size()>Cmax)
				{
					IauxPOP.clear();
					for(unsigned int w = 0; w< POP[k].size(); w++) {IauxPOP.push_back(POP[k][w]);}
					Cmax=POP[k].size();
					
				}
				
			}		
		}

	
	for(int i = 0; i < (tp); i++)      
	{ POP[i].clear();LT[i].clear();}    

	GeraPopulacao(grafo,VG,GR,tp,POP);

	POP[0].clear(); 
	for(unsigned int i = 0; i < IauxPOP.size(); i++)      
	{    
	  POP[0].push_back(IauxPOP[i]);		
	}
		
	
	
	QI=QI+pQI;	
	Temp=Temp-1;
	}
tempf = clock();
double tempo_gasto =((tempf - tempi) / (CLOCKS_PER_SEC/1000));	
int erro=0;

VerificaClique(IauxPOP,grafo,erro);
cout<<"valor " <<Cmax<< endl;
cout<<"tempo " <<tempo_gasto/1000<<endl;




return 0;
}

