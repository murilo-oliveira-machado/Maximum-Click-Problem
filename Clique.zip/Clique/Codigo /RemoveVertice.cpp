#include <vector>
#include <iostream>
#include <random>
#include <chrono>

using namespace std;
void RemoveVertice(vector<int>&C,vector<int>GR,int ver,vector<vector<int>>&LT,int IP)
{
	unsigned seed = chrono::system_clock::now().time_since_epoch().count();
	default_random_engine generator (seed);	
	vector<int> MGC;
	for (unsigned int i=0; i<C.size(); i++)
	{
		MGC.push_back(ver-GR[C[i]]);
	}
    int aux;
    discrete_distribution<int> second (MGC.begin(),MGC.end());
	aux = second(generator);
	
//	LT[IP].push_back(C[aux]);
	C.erase(C.begin()+aux);
	
		
}
