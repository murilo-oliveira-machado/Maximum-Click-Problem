#include <vector>
#include <iostream>
#include <random>
#include <chrono>

using namespace std;
void AtualizaLT(vector<vector<int>>&LT,vector<vector<int>> &I,int IP)
{
	for (unsigned int i=0; i<LT[IP].size(); i++)
	{
		if (I[IP][LT[IP][i]]==5)
		{
			LT[IP].erase(LT[IP].begin()+i);
			I[IP][LT[IP][i]]=0;
		}
		else
		{
			I[IP][LT[IP][i]]=I[IP][LT[IP][i]]+1;
		}	
	}	
		
}
