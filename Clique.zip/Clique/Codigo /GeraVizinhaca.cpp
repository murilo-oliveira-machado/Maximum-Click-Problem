#include <vector>
#include <iostream>
using namespace std;
void GeraVizinhaca(vector<int> &C,int ** grafo,vector<vector<int>>LT,vector<int> VG,vector<int> &V,int IP)
{
unsigned int cot;
int sinal;
	
	for (unsigned int i=0; i<VG.size(); i++)
	{

		cot=0;
		for (unsigned int j=0; j<C.size(); j++)
		{
			
			if (grafo[VG[i]][C[j]]==1)
			{
				cot=cot+1;
			}				
		}

		if ( cot==C.size())
		{
		    sinal=0;
			for (unsigned int j=0; j<LT[IP].size(); j++)
			{	
				if (VG[i]==LT[IP][j])
				{
					sinal=1;
				}
				
			}
			
			if (sinal==0)
			{
				V.push_back(VG[i]);
			}
			
		}
			
	}

	
	
}
